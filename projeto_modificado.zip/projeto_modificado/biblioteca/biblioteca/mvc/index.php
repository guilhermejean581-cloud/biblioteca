<?php




session_start();
error_reporting(e_all);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);





define("app", "http://localhost/projeto_modificado/biblioteca/biblioteca/mvc");

include 'model/leitor.php';
include 'controller/homecontroller.php';
include 'controller/leitorcontroller.php';
include 'controller/logincontroller.php';


$url = isset($_get['url']) ? $_get['url'] : '';

if (!isset($_session['logado']) && $url != 'login/entrar') {
    $controlador = new logincontroller();
    $controlador->index();
    exit;
}

if (empty($url)) {
    $controlador = new homecontroller();
    $controlador->index();
    exit;
}
$partes = explode('/', $url);
$nomecontrolador = $partes[0] . 'controller';
$acao = isset($partes[1]) ? $partes[1] : 'index';

if (class_exists($nomecontrolador)) {
    $controlador = new $nomecontrolador();
    if (count($partes) <= 2) {
        $controlador->$acao();
    } else {
        $controlador->$acao($partes[2]);
    }
} else {
    echo "pagina nao encontrada";
}
?>