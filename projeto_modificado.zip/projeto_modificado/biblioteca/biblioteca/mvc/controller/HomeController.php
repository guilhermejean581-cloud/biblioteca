<?php
class homecontroller {
    function index() {
        $model               = new leitor();
        $totalleitores       = $model->countall();
        $ultimasinscricoes   = $model->getrecentes(5);
        include 'view/home.php';
    }
}
?>