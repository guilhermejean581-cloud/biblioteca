<?php
class leitorcontroller {
    function listar() {

        $model = new leitor();
        $leitores = $model->getall();
        include 'view/listagemleitor.php';
    }

    function novo() {
        $dados = [
            'id'              => 0,
            'nome'            => '',
            'email'           => '',
            'telefone'        => '',
            'cpf'             => '',
            'data_nascimento' => '',
            'endereco'        => ''
        ];
        include 'view/formularioleitor.php';
    }

    function gravar() {
        $foto_perfil = '';
        if (isset($_files['foto_perfil']) && $_files['foto_perfil']['error'] == 0) {
            $diretorio = 'uploads/perfil/';
            if (!is_dir($diretorio)) {
                mkdir($diretorio, 0777, true);
            }
            $nome_arquivo = time() . '_' . basename($_files['foto_perfil']['name']);
            $foto_perfil = $diretorio . $nome_arquivo;
            move_uploaded_file($_files['foto_perfil']['tmp_name'], $foto_perfil);
        }

        $dados = [
            'id'              => $_post['id'],
            'nome'            => $_post['nome'],
            'email'           => $_post['email'],
            'telefone'        => $_post['telefone'],
            'cpf'             => $_post['cpf'],
            'data_nascimento' => $_post['data_nascimento'],
            'endereco'        => $_post['endereco'],
            'foto_perfil'     => $foto_perfil
        ];

        $model = new leitor();
        if ($dados['id'] == 0) {
            $model->insert($dados);
            $this->enviaremail($dados['email'], $dados['nome']);
        } else {
            $model->update($dados);
        }
        header('location: ' . app . '/leitor/listar');
    }

    function editar($id) {
        $model = new leitor();
        $dados = $model->getbyid($id);
        include 'view/formularioleitor.php';
    }

    function excluir($id) {
        $model = new leitor();
        $model->delete($id);
        header('location: ' . app . '/leitor/listar');
    }

    function enviaremail($email_destino, $nome) {
        $assunto = 'cadastro realizado com sucesso';
        $mensagem = "ola $nome, seu perfil de leitor foi criado no sistema da biblioteca.";
        $cabecalhos = 'from: admin@sistema.com' . "\r\n" . 'reply-to: admin@sistema.com';
        @mail($email_destino, $assunto, $mensagem, $cabecalhos);
    }

    function relatorio() {
        require('fpdf/fpdf.php');
        $pdf = new fpdf();
        $pdf->addpage();
        $pdf->setfont('arial', 'b', 16);
        $pdf->cell(0, 10, 'relatorio de leitores cadastrados', 0, 1, 'c');
        $pdf->ln(10);
        
        $model = new leitor();
        $leitores = $model->getall();
        
        $pdf->setfont('arial', '', 12);
        foreach ($leitores as $l) {
            $texto = "nome: " . $l['nome'] . " | e-mail: " . $l['email'] . " | cpf: " . $l['cpf'];
            $pdf->cell(0, 10, $texto, 0, 1);
        }
        $pdf->output();
    }
}
?>