<?php
class livrocontroller {
    function getconnection() {
        $conexao = new pdo('pgsql:host=localhost;dbname=biblioteca', 'postgres', '123456');
        $conexao->setattribute(pdo::attr_errmode, pdo::errmode_exception);
        return $conexao;
    }

    function index() {
        echo "listagem de livros";
    }

    function novo() {
        $conexao = $this->getconnection();
        $categorias = $conexao->query('select * from categoria')->fetchall();
        $autores = $conexao->query('select * from autor')->fetchall();
        include 'view/formulariolivro.php';
    }

    function gravar() {
        $titulo = $_post['titulo'];
        $id_categoria = $_post['id_categoria'];
        $autores = $_post['autores'];
        
        $capa = '';
        if (isset($_files['capa']) && $_files['capa']['error'] == 0) {
            $diretorio = 'uploads/';
            if (!is_dir($diretorio)) {
                mkdir($diretorio, 0777, true);
            }
            $capa = $diretorio . basename($_files['capa']['name']);
            move_uploaded_file($_files['capa']['tmp_name'], $capa);
        }

        $conexao = $this->getconnection();
        $sentenca = $conexao->prepare('insert into livro (titulo, id_categoria, capa) values (?, ?, ?) returning id');
        $sentenca->execute([$titulo, $id_categoria, $capa]);
        $id_livro = $sentenca->fetchcolumn();

        if (!empty($autores)) {
            foreach ($autores as $id_autor) {
                $stmt = $conexao->prepare('insert into livro_autor (id_livro, id_autor) values (?, ?)');
                $stmt->execute([$id_livro, $id_autor]);
            }
        }
        
        header('location: ' . app . '/livro/novo');
    }

    function relatorio() {
        require('fpdf/fpdf.php');
        $pdf = new fpdf();
        $pdf->addpage();
        $pdf->setfont('arial', 'b', 16);
        $pdf->cell(40, 10, 'relatorio de livros');
        
        $conexao = $this->getconnection();
        $livros = $conexao->query('select * from livro')->fetchall();
        
        $pdf->setfont('arial', '', 12);
        foreach ($livros as $l) {
            $pdf->ln(10);
            $pdf->cell(40, 10, $l['titulo']);
        }
        
        $pdf->output();
    }

    function enviar() {
        $para = 'aluno@ifms.edu.br';
        $assunto = 'aviso do sistema';
        $mensagem = 'um novo livro foi registrado';
        $cabecalhos = 'from: admin@localhost' . "\r\n" . 'reply-to: admin@localhost';

        @mail($para, $assunto, $mensagem, $cabecalhos);
        echo "email encaminhado";
    }
}
?>