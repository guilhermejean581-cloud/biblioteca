<?php
class logincontroller {
    function index() {
        include 'view/login.php';
    }

    function entrar() {
        $email = $_post['email'];
        $senha = $_post['senha'];

        if ($email == 'admin@email.com' && $senha == '123456') {
            $_session['logado'] = true;
            header('location: ' . app);
        } else {
            echo "dados invalidos";
        }
    }

    function sair() {
        unset($_session['logado']);
        session_destroy();
        header('location: ' . app);
    }
}
?>