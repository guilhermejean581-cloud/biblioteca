<?php include 'view/layout.php';
layoutheader($dados['id'] == 0 ? 'inscrever leitor' : 'editar leitor'); ?>

<div class="top-bar">
    <h1 class="page-title">
        <?php echo ($dados['id'] == 0) ? 'inscrever leitor' : 'editar leitor'; ?>
    </h1>
    <a href="<?php echo app; ?>/leitor/listar" class="btn btn-biblioteca">voltar</a>
</div>

<div class="card">
    <div class="card-body">
        <form action="<?php echo app; ?>/leitor/gravar" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $dados['id']; ?>">

            <label>nome completo *</label>
            <input type="text" class="form-control" name="nome" value="<?php echo htmlspecialchars($dados['nome']); ?>" required>

            <label>e-mail *</label>
            <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($dados['email']); ?>" required>

            <label>telefone</label>
            <input type="text" class="form-control" name="telefone" value="<?php echo htmlspecialchars($dados['telefone']); ?>">

            <label>cpf *</label>
            <input type="text" class="form-control" name="cpf" value="<?php echo htmlspecialchars($dados['cpf']); ?>" required>

            <label>data de nascimento</label>
            <input type="date" class="form-control" name="data_nascimento" value="<?php echo htmlspecialchars($dados['data_nascimento']); ?>">

            <label>endereco</label>
            <input type="text" class="form-control" name="endereco" value="<?php echo htmlspecialchars($dados['endereco']); ?>">

            <label>foto de perfil (upload de imagem)</label>
            <input type="file" class="form-control" name="foto_perfil" accept="image/png, image/jpeg">

            <button type="submit" class="btn btn-biblioteca mt-3">salvar leitor</button>
        </form>

        <hr>
        <h3>acoes extras do pdf</h3>
        <a href="<?php echo app; ?>/leitor/relatorio" class="btn btn-danger">gerar relatorio pdf</a>
    </div>
</div>

<?php layoutfooter(); ?>