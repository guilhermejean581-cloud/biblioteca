<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>cadastro de livro</title>
</head>
<body>
<h2>cadastrar novo livro</h2>
<form action="<?php echo app; ?>/livro/gravar" method="post" enctype="multipart/form-data">
    
    <label>titulo:</label>
    <input type="text" name="titulo" required>
    <br><br>

    <label>categoria (relacao 1 x n):</label>
    <select name="id_categoria">
    <?php foreach ($categorias as $cat): ?>
        <option value="<?php echo $cat['id']; ?>"><?php echo $cat['nome']; ?></option>
    <?php endforeach; ?>
    </select>
    <br><br>

    <label>autores (relacao n x m):</label>
    <select name="autores[]" multiple required>
    <?php foreach ($autores as $aut): ?>
        <option value="<?php echo $aut['id']; ?>"><?php echo $aut['nome']; ?></option>
    <?php endforeach; ?>
    </select>
    <br><br>

    <label>capa (upload de arquivo):</label>
    <input type="file" name="capa">
    <br><br>

    <button type="submit">salvar livro</button>
</form>

<hr>
<h3>acoes extras</h3>
<a href="<?php echo app; ?>/livro/relatorio">gerar relatorio pdf</a>
<br><br>
<a href="<?php echo app; ?>/livro/enviar">testar encaminhamento de email</a>
<br><br>
<a href="<?php echo app; ?>/login/sair">sair do sistema</a>

</body>
</html>