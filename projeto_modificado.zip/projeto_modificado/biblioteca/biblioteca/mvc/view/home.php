<?php include 'view/layout.php'; layoutheader('dashboard'); ?>

<div class="top-bar">
    <h1 class="page-title">dashboard</h1>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                total de leitores: <?php echo $totalleitores; ?>
            </div>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-body">
        <h3>ultimas inscricoes</h3>
        <ul>
        <?php foreach ($ultimasinscricoes as $leitor): ?>
            <li><?php echo htmlspecialchars($leitor['nome']); ?> - <?php echo htmlspecialchars($leitor['cpf']); ?></li>
        <?php endforeach; ?>
        </ul>
    </div>
</div>

<?php layoutfooter(); ?>