<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>acesso ao sistema</title>
</head>
<body>
<h2>fazer login</h2>
<form action="<?php echo app; ?>/login/entrar" method="post">
    <label>email:</label>
    <input type="email" name="email" required>
    <br><br>
    <label>senha:</label>
    <input type="password" name="senha" required>
    <br><br>
    <button type="submit">entrar</button>
</form>
</body>
</html>