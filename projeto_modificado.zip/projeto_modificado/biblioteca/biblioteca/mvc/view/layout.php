<?php
function layoutheader($titulo = 'biblioteca') {
?>
<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title><?php echo $titulo; ?> - bibliosys</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="sidebar">
    <h2>bibliosys</h2>
    <nav>
        <a href="<?php echo app; ?>" class="nav-link">dashboard</a>
        <a href="<?php echo app; ?>/leitor/listar" class="nav-link">leitores</a>
        <a href="<?php echo app; ?>/livro/novo" class="nav-link">livros e extras</a>
        <a href="<?php echo app; ?>/login/sair" class="nav-link">sair</a>
    </nav>
</div>

<div class="main-content">
<?php
}

function layoutfooter() {
?>
</div>
</body>
</html>
<?php
}
?>