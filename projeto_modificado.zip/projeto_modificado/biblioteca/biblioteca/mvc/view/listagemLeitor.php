<?php include 'view/layout.php'; layoutheader('leitores'); ?>

<div class="top-bar">
    <h1 class="page-title">leitores inscritos</h1>
    <a href="<?php echo app; ?>/leitor/novo" class="btn btn-biblioteca">inscrever leitor</a>
</div>

<div class="card">
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>id</th>
                    <th>nome</th>
                    <th>cpf</th>
                    <th>acoes</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($leitores as $leitor): ?>
                <tr>
                    <td><?php echo $leitor['id']; ?></td>
                    <td><?php echo htmlspecialchars($leitor['nome']); ?></td>
                    <td><?php echo htmlspecialchars($leitor['cpf']); ?></td>
                    <td>
                        <a href="<?php echo app; ?>/leitor/editar/<?php echo $leitor['id']; ?>" class="btn btn-primary">editar</a>
                        <a href="<?php echo app; ?>/leitor/excluir/<?php echo $leitor['id']; ?>" class="btn btn-danger">excluir</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php layoutfooter(); ?>