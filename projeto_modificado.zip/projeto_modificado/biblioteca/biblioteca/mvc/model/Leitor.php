<?php
class leitor {
    function getconnection() {
        $conexao = new pdo('pgsql:host=localhost;dbname=biblioteca', 'postgresql', 'postgresql');
        $conexao->setattribute(pdo::attr_errmode, pdo::errmode_exception);
        return $conexao;
    }

    function getall() {
        $conexao  = $this->getconnection();
        $sentenca = $conexao->query('select * from leitor order by nome', pdo::fetch_assoc);
        return $sentenca->fetchall();
    }

    function getbyid($id) {
        $conexao  = $this->getconnection();
        $sentenca = $conexao->prepare('select * from leitor where id = :id');
        $sentenca->bindparam(':id', $id);
        $sentenca->execute();
        return $sentenca->fetch(pdo::fetch_assoc);
    }

    function insert($dados) {
        $conexao  = $this->getconnection();
        $sentenca = $conexao->prepare(
            'insert into leitor (nome, email, telefone, cpf, data_nascimento, endereco, foto_perfil)
             values (:nome, :email, :telefone, :cpf, :data_nascimento, :endereco, :foto_perfil)'
        );
        $sentenca->bindparam(':nome',             $dados['nome']);
        $sentenca->bindparam(':email',            $dados['email']);
        $sentenca->bindparam(':telefone',         $dados['telefone']);
        $sentenca->bindparam(':cpf',              $dados['cpf']);
        $sentenca->bindparam(':data_nascimento',  $dados['data_nascimento']);
        $sentenca->bindparam(':endereco',         $dados['endereco']);
        $sentenca->bindparam(':foto_perfil',      $dados['foto_perfil']);
        $sentenca->execute();
    }

    function update($dados) {
        $conexao  = $this->getconnection();
        $sentenca = $conexao->prepare(
            'update leitor
             set nome = :nome, email = :email, telefone = :telefone,
                 cpf = :cpf, data_nascimento = :data_nascimento, endereco = :endereco
             where id = :id'
        );
        $sentenca->bindparam(':nome',             $dados['nome']);
        $sentenca->bindparam(':email',            $dados['email']);
        $sentenca->bindparam(':telefone',         $dados['telefone']);
        $sentenca->bindparam(':cpf',              $dados['cpf']);
        $sentenca->bindparam(':data_nascimento',  $dados['data_nascimento']);
        $sentenca->bindparam(':endereco',         $dados['endereco']);
        $sentenca->bindparam(':id',               $dados['id']);
        $sentenca->execute();
    }

    function delete($id) {
        $conexao  = $this->getconnection();
        $sentenca = $conexao->prepare('delete from leitor where id = :id');
        $sentenca->bindparam(':id', $id);
        $sentenca->execute();
    }

    function countall() {
        $conexao  = $this->getconnection();
        $sentenca = $conexao->query('select count(*) as total from leitor');
        $row = $sentenca->fetch(pdo::fetch_assoc);
        return $row['total'];
    }

    function getrecentes($limite = 5) {
        $conexao  = $this->getconnection();
        $sentenca = $conexao->prepare(
            'select * from leitor order by data_inscricao desc limit :limite'
        );
        $sentenca->bindparam(':limite', $limite, pdo::param_int);
        $sentenca->execute();
        return $sentenca->fetchall(pdo::fetch_assoc);
    }
}
?>