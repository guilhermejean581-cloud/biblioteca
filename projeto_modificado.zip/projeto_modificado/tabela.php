<?php
$dados = [
    ["nome" => "jean guilherme", "idade" => 17, "cidade" => "São Paulo"],
    ["nome" => "jean guilherme", "idade" => 18, "cidade" => "Rio de Janeiro"],
    ["nome" => "jean guilherme", "idade" => 16, "cidade" => "Curitiba"],
    ["nome" => "jean guilherme", "idade" => 19, "cidade" => "Belo Horizonte"]
];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Tabela</title>
<style>
table { border-collapse: collapse; width: 50%; }
th, td { border: 1px solid #000; padding: 8px; text-align: center; }
</style>
</head>
<body>

<table>
<tr>
<th>Nome</th>
<th>Idade</th>
<th>Cidade</th>
</tr>

<?php foreach($dados as $pessoa): ?>
<tr>
<td><?= $pessoa["nome"] ?></td>
<td><?= $pessoa["idade"] ?></td>
<td><?= $pessoa["cidade"] ?></td>
</tr>
<?php endforeach; ?>

</table>

</body>
</html>
